package com.example.tp.Model

open class Fight (
    var name: String,
    var at: Int,
    var cible: String
)