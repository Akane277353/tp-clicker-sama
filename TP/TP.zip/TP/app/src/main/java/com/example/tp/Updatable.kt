package com.example.tp

interface Updatable {

    fun update()
}