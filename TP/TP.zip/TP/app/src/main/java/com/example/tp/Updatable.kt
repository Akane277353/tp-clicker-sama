package com.example.tp

import com.example.tp.Model.PlayableChar

interface Updatable {

    fun update()
}