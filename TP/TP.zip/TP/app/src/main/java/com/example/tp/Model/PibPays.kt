package com.example.tp.Model

class PibPays(
    var pays: String,
    var pib: Int
)